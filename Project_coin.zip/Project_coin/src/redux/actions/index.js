import posts from './posts'

const actionCreators = {
  posts
}

export {
  actionCreators as default,
  posts
}

export * from './posts'
