# React-Redux-Saga-Hot-Starter
React, Redux, Redux-Saga, React-Router,

Строит картас проекта для работы с React+Redux-Saga.
В стартере установлена уникальная система экшенов)

## Установка и запуск
1. Устанавливаем зависимости
```
npm instal
```
2. Запускаем и наслаждаемся
```
npm start
```

## Ссилка на репозиторий
https://github.com/EarlOld/react-redux-saga-hot-starter
